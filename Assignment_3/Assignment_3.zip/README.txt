Team Member: Zhi Jiang, Wenbo Hou

1. Don't remove "stop_word_list.txt" from this folder 

2. I have provided makefile and you can just type "make all" to run our program

3. The program will generate "preprocessed_train.txt", "preprocessed_test.txt", and "results.txt" automatically